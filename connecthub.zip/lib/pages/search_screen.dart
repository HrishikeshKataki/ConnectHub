import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connecthub/pages/services/service_details.dart';
import 'package:flutter/cupertino.dart';
import "package:flutter/material.dart";
import 'package:connecthub/utils/my_colors.dart';
import 'package:flutter/widgets.dart';

class FieldModel {
  String? freelancer_name;
  String? freelancer_profession;
  String? freelancer_experience;
  FieldModel(this.freelancer_name, this.freelancer_experience,
      this.freelancer_profession);
}

class Search extends StatefulWidget {
  static const routename = "search";

  const Search({super.key});

  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  List<FieldModel> main_field_list = [];
  List<FieldModel> display_list = [];

  @override
  void initState() {
    super.initState();
    fetchFreelancers();
  }

  Future<void> fetchFreelancers() async {
    final QuerySnapshot result =
        await FirebaseFirestore.instance.collection('freelancer').get();
    final List<DocumentSnapshot> documents = result.docs;

    setState(() {
      main_field_list = documents
          .map((doc) => FieldModel(
                doc['name'],
                doc['profession'],
                doc['experience'],
              ))
          .toList();
      display_list = List.from(main_field_list);
    });
  }

  void Updatelist(String value) {
    setState(() {
      display_list = main_field_list
          .where((element) => element.freelancer_name!
              .toLowerCase()
              .contains(value.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 40, left: 12),
            child: Row(
              children: [
                Text("Search for Your Freelancer!",
                    style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: primary)),
              ],
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: TextField(
              onChanged: (value) => Updatelist(value),
              style: const TextStyle(color: secondaryText),
              decoration: InputDecoration(
                filled: true,
                fillColor: sbg,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none),
                hintText: "Mobile Development",
                prefixIcon: const Icon(Icons.search),
                prefixIconColor: primary,
                suffixIcon: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primary,
                    padding: const EdgeInsets.all(22),
                  ),
                  onPressed: () {},
                  child: const Icon(
                    Icons.search,
                    color: white,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 10.0,
          ),
          Expanded(
            child: display_list.isEmpty
                ? const Center(
                    child: Text("No result found",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        )))
                : ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: display_list.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ServiceDetails(
                                title: display_list[index].freelancer_name!,
                                desc: "Service description",
                                uploadedBy:
                                    display_list[index].freelancer_name!,
                                price: 5000, // Add a price here
                              ),
                            ),
                          );
                        },
                        child: ListTile(
                          title: Text(display_list[index].freelancer_name!,
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              )),
                          subtitle:
                              Text(display_list[index].freelancer_profession!,
                                  style: const TextStyle(
                                    fontSize: 15,
                                  )),
                          trailing:
                              Text(display_list[index].freelancer_experience!,
                                  style: const TextStyle(
                                    fontSize: 15,
                                  )),
                        ),
                      );
                    },
                  ),
          )
        ],
      ),
    ));
  }
}
