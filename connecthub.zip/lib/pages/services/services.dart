import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connecthub/pages/search_screen.dart';
import 'package:connecthub/pages/services/service_tile.dart';
import 'package:connecthub/utils/my_colors.dart';
import 'package:connecthub/utils/txt.dart';
import 'package:flutter/material.dart';

class Services extends StatelessWidget {
  final String srvCategory; // Service Category
  const Services({super.key, required this.srvCategory});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            elevation: 2,
            iconTheme: const IconThemeData(color: white),
            backgroundColor: primary,
            title: Text(
              srvCategory,
              style: txt.appBarTitle,
            ),
            actions: [
              IconButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const Search()));
                  },
                  icon: const Icon(
                    Icons.search,
                    color: white,
                    size: 28,
                  )),
            ],
            floating: true,
          ),
          SliverPadding(
            padding: const EdgeInsets.only(top: 10),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 8, bottom: 5),
                    child: Row(
                      children: [
                        if (srvCategory == 'Popular Services')
                          const Text(
                            'Choose from the most Popular Services',
                            style: TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w500),
                          )
                        else if (srvCategory == 'recommend')
                          const Text(
                            'Services catered according to your interests',
                            style: TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w500),
                          )
                        else
                          Flexible(
                            child: Text(
                              'Look for the best Services under $srvCategory',
                              style: const TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          FutureBuilder(
            future: _fetchServices(srvCategory),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                List<ServiceData> services = snapshot.data!;
                return SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) {
                      return ServiceTile(
                        serviceTitle: services[index].title,
                        serviceDesc: services[index].description,
                        servicePrice: services[index].price,
                        uploadedBy: services[index].userId,
                      );
                    },
                    childCount: services.length,
                  ),
                );
              } else {
                return const SliverToBoxAdapter(
                  child: Center(child: CircularProgressIndicator()),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Future<List<ServiceData>> _fetchServices(String srvCategory) async {
    List<ServiceData> services = [];

    // Fetch all documents in the 'Service' collection
    QuerySnapshot serviceSnapshot =
        await FirebaseFirestore.instance.collection('Service').get();

    // Loop through each document in the 'Service' collection
    for (var serviceDoc in serviceSnapshot.docs) {
      // Fetch all documents in the 'Yourservices' subcollection
      QuerySnapshot yourservicesSnapshot = await serviceDoc.reference
          .collection('Yourservices')
          .where('title', isEqualTo: srvCategory)
          .get();

      // Loop through each document in the 'Yourservices' subcollection
      for (var yourserviceDoc in yourservicesSnapshot.docs) {
        // Extract the data from the document
        String title = yourserviceDoc.get('title');
        String description = yourserviceDoc.get('description');
        int price = yourserviceDoc.get('price');
        String userId = serviceDoc.id; // Get the parent document ID (UserId)

        // Create a ServiceData object
        ServiceData serviceData =
            ServiceData(title, description, price, userId);

        // Add the service data to the list
        services.add(serviceData);
      }
    }

    return services;
  }
}

class ServiceData {
  final String title;
  final String description;
  final int price;
  final String userId;

  ServiceData(this.title, this.description, this.price, this.userId);
}
