class layout {
  static const padding = 16.0;
  static const radius = 16.0;
  static const elevation = 5.0;

  static const curvedNavBarHeight = 50.0;

  static const iconSmall = 20.0;
  static const iconMedium = 30.0;
  static const iconLarge = 35.0;
}
