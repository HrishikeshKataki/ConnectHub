import 'package:flutter/material.dart';

List<String> serviceCategories = [
  'Architecture and Construction',
  'Education and Training',
  'Development - Programming',
  'Business',
  'Information Technology',
  'Human Resources',
  'Marketing',
  'Design',
  'Accounting',
];

String? name;
String? user_image;
String? address;
String? id;

String? avatarURL;
NetworkImage? avatarImage;
