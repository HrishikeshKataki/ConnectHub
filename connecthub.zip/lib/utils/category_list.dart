final List<String> categories = [
  "WEB DEVELOPMENT",
  "FLUTTER",
  "REACT NATIVE",
  "GRAPHICS DESIGN",
  "UI/UX",
  "APP DEVELOPMENT",
  "PROJECT MANAGEMENT",
];
