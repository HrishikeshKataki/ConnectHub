package com.example.connecthub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
