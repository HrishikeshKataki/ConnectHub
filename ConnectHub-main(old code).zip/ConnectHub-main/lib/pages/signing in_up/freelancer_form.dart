import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connecthub/pages/signing%20in_up/sign_up_screen.dart';
import 'package:connecthub/utils/my_colors.dart';
import 'package:connecthub/utils/txt.dart';
import 'package:connecthub/widgets/custom_button.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

class FreelancerForm extends StatefulWidget {
  const FreelancerForm({Key? key}) : super(key: key);

  @override
  _FreelancerFormState createState() => _FreelancerFormState();
}

class _FreelancerFormState extends State<FreelancerForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _ageController = TextEditingController();
  final _nationalityController = TextEditingController();
  final _skillsController = TextEditingController();
  final _marketNameController = TextEditingController();
  final _summaryController = TextEditingController();
  final _servicesController = TextEditingController();
  final _contactController = TextEditingController();
  File? _image;

  final _firebaseStorage = FirebaseStorage.instanceFor(
    bucket: 'gs://connecthub-7c7cf.appspot.com',
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tell us about Yourself'),
        titleTextStyle: txt.appBarTitle,
        iconTheme: const IconThemeData(color: white),
        backgroundColor: primary,
      ),
      body: ListView(
        children: [
          Form(
            key: _formKey,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _buildTextFieldWithLabelAndValidator(
                    label: 'Name',
                    controller: _nameController,
                  ),
                  _buildTextFieldWithLabelAndValidator(
                    label: 'Age',
                    controller: _ageController,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  ),
                  _buildTextFieldWithLabelAndValidator(
                    label: 'Nationality',
                    controller: _nationalityController,
                  ),
                  _buildTextFieldWithLabelAndValidator(
                    label: 'Skills',
                    controller: _skillsController,
                  ),
                  _buildTextFieldWithLabelAndValidator(
                    label: 'Profession',
                    controller: _marketNameController,
                  ),
                  _buildTextFieldWithLabelAndValidator(
                    label: 'Brief summary about yourself',
                    controller: _summaryController,
                  ),
                  _buildTextFieldWithLabelAndValidator(
                    label: 'Services you want to provide',
                    controller: _servicesController,
                  ),
                  _buildTextFieldWithLabelAndValidator(
                    label: 'Contact details',
                    controller: _contactController,
                  ),
                  const SizedBox(height: 16.0),
                  GestureDetector(
                    onTap: _pickImage,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _image == null
                           ? Container(
                                width: 100,
                                height: 100,
                                color: Colors.grey.withOpacity(0.3),
                                child: const Icon(
                                  Icons.camera_alt,
                                  size: 50,
                                  color: Colors.grey,
                                ),
                              )
                            : Image.file(_image!, fit: BoxFit.cover),
                        const SizedBox(height: 5.0),
                        Text(
                          'Tap here to add image',
                          style: const TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16.0),
                  CustomButton(
                    buttonText: 'Submit',
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        await saveFormDataToFirestore();
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SignUpScreen(userData: _getUserData()),
                          ),
                        );
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextFieldWithLabelAndValidator({
    required String label,
    required TextEditingController controller,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: '$label',
        ),
        validator: validator,
        inputFormatters: inputFormatters,
      ),
    );
  }

  Future<String?> _uploadImage(String documentId) async {
    if (_image == null) return null;

    try {
      final ref = _firebaseStorage.ref().child('freelancer_images').child(documentId);
      await ref.putFile(_image!);
      final imageUrl = await ref.getDownloadURL();
     return imageUrl;
    } catch (error) {
      print('Error uploading image: $error');
      return null;
    }
  }

  Future<void> saveFormDataToFirestore() async {
    try {
      final imageUrl = await _uploadImage(DateTime.now().millisecondsSinceEpoch.toString());
   
        final ref = FirebaseFirestore.instance.collection('freelancer').add({
          'name': _nameController.text,
          'age': int.parse(_ageController.text),
          'nationality': _nationalityController.text,
          'skills': _skillsController.text,
          'marketName': _marketNameController.text,
          'summary': _summaryController.text,
          'services': _servicesController.text,
          'contact': _contactController.text,
          'image_url': imageUrl,
        });
        print('Form data saved to Firestore successfully');

    } catch (error) {
      print('Error saving form data to Firestore: $error');
    }
  }

  Map<String, dynamic> _getUserData() {
    return {
      'name': _nameController.text,
      'age': _ageController.text,
      'nationality': _nationalityController.text,
      'skills': _skillsController.text,
      'marketName': _marketNameController.text,
      'summary': _summaryController.text,
      'services': _servicesController.text,
      'contact': _contactController.text,
    };
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }
}
