import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: AddServiceScreen(),
  ));
}

class AddServiceScreen extends StatefulWidget {
  const AddServiceScreen({super.key});

  @override
  _AddServiceScreenState createState() => _AddServiceScreenState();
}

class _AddServiceScreenState extends State<AddServiceScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _serviceTitle,
      _serviceDescription,
      _servicePrice,
      _serviceImage,
      _included1,
      _included2,
      _included3;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Service'),
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: <Widget>[
              TextFormField(
                decoration: const InputDecoration(labelText: 'Service Title'),
                validator: (value) {
                  if (value == null) {
                    return 'Please enter a service title';
                  }
                  return null;
                },
                onSaved: (value) => _serviceTitle = value,
              ),
              TextFormField(
                decoration:
                    const InputDecoration(labelText: 'Service Description'),
                validator: (value) {
                  if (value == null) {
                    return 'Please enter a service description';
                  }
                  return null;
                },
                onSaved: (value) => _serviceDescription = value,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Service Price'),
                validator: (value) {
                  if (value == null) {
                    return 'Please enter a service price';
                  }
                  return null;
                },
                onSaved: (value) => _servicePrice = value,
              ),
              TextFormField(
                decoration: const InputDecoration(
                    labelText: 'Service Image (optional)'),
                onSaved: (value) => _serviceImage = value,
              ),
              TextFormField(
                decoration:
                    const InputDecoration(labelText: 'Included in Service 1'),
                validator: (value) {
                  if (value == null) {
                    return 'Please enter something included in the service';
                  }
                  return null;
                },
                onSaved: (value) => _included1 = value,
              ),
              TextFormField(
                decoration:
                    const InputDecoration(labelText: 'Included in Service 2'),
                validator: (value) {
                  if (value == null) {
                    return 'Please enter something included in the service';
                  }
                  return null;
                },
                onSaved: (value) => _included2 = value,
              ),
              TextFormField(
                decoration:
                    const InputDecoration(labelText: 'Included in Service 3'),
                validator: (value) {
                  if (value == null) {
                    return 'Please enter something included in the service';
                  }
                  return null;
                },
                onSaved: (value) => _included3 = value,
              ),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    // Here you can add the logic to add the service to your database or backend.
                    print(
                        'Service added: $_serviceTitle, $_serviceDescription, $_servicePrice, $_serviceImage, $_included1, $_included2, $_included3');
                  }
                },
                child: const Text('Add Service'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
